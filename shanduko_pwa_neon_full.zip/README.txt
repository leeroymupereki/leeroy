
Shanduko PWA assets (generated)
Theme color: #000000

Files to copy into your client/public/ folder (for Vite projects):
 - manifest.json
 - service-worker.js
 - offline.html
 - assets/icons/* (icon-192..icon-512, adaptive-foreground.png, adaptive-background.png)
 - assets/splash/* (iOS splash images)

Steps:
1) Copy these files into client/public/
2) Register the service worker in your src/main.jsx (or index.html):
   if ('serviceWorker' in navigator) {
     window.addEventListener('load', () => navigator.serviceWorker.register('/service-worker.js'));
   }
3) Build:
   cd client
   npm install
   npm run build
4) Serve dist/ over HTTPS and test 'Add to Home screen' (or use `npm run preview` for quick checks).

Generated asset list:
