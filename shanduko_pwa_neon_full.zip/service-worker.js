
const CACHE_STATIC = 'shanduko-static-v1';
const CACHE_RUNTIME = 'shanduko-runtime-v1';
const PRECACHE_URLS = [
  '/',
  '/index.html',
  '/pro-logo-maker.html',
  '/video-editor-pro.html',
  '/animation-studio-pro.html',
  '/css/styles.css',
  '/js/main.js',
  '/js/logo-maker.js',
  '/js/video-editor.js',
  '/js/animation.js',
  '/offline.html'
];

self.addEventListener('install', event=>{
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_STATIC).then(cache => cache.addAll(PRECACHE_URLS))
  );
});

self.addEventListener('activate', event=>{
  event.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.map(k => { if (k !== CACHE_STATIC && k !== CACHE_RUNTIME) return caches.delete(k); })
    ))
  );
  self.clients.claim();
});

self.addEventListener('fetch', event=>{
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);

  // Network-first for API requests (so data stays fresh)
  if (url.pathname.startsWith('/api') || url.hostname !== self.location.hostname) {
    event.respondWith(networkFirst(event.request));
    return;
  }

  // Cache-first for other requests (static assets)
  event.respondWith(cacheFirst(event.request));
});

async function cacheFirst(request) {
  const cache = await caches.open(CACHE_STATIC);
  const cached = await cache.match(request);
  if (cached) return cached;
  try {
    const response = await fetch(request);
    if (response && response.status === 200) cache.put(request, response.clone());
    return response;
  } catch (err) {
    if (request.mode === 'navigate') {
      const offline = await cache.match('/offline.html');
      if (offline) return offline;
    }
    throw err;
  }
}

async function networkFirst(request) {
  const cache = await caches.open(CACHE_RUNTIME);
  try {
    const response = await fetch(request);
    if (response && response.status === 200) cache.put(request, response.clone());
    return response;
  } catch (err) {
    const cached = await cache.match(request);
    if (cached) return cached;
    throw err;
  }
}
